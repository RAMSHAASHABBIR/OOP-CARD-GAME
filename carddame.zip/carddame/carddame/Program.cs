﻿using carddame.Properties;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace carddame
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int score = 0;
            Deck d = new Deck();
            d.shuffle();
            bool correctguess = true;
            Card c =  d.getcard();
            while (correctguess)
            {
                string input = Console.ReadLine();
                Card n = d.getcard();
                d.scoring(ref score);
                if (c.number>n.number && input == "higher")
                {
                    correctguess = false;
                }
                else if(c.number < n.number && input == "lower")
                {
                    correctguess = false;
                }
                c = n;
              //  Console.WriteLine(c.number < n.number);
            }
          
            Console.WriteLine("you lost");
            d.print(ref score);
            Console.ReadKey();
        }
    }
}
