﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace carddame.Properties
{
     class Deck
    {

        public static List<Card> decks = new List<Card>();

        public Deck()
        {
            for(int j =0; j < 4; j++)
            {
                for(int k = 0; k < 13; k++)
                {
                    Card card = new Card(j,k);
                    decks.Add(card);
                }
            }
        }
        public void shuffle()
        {
            Random random = new Random(); 
            for(int j =0; j< 51;j++)
            {
                int c = random.Next(0, 52);
                Card temp = decks[j];
                decks[j] = decks[c];
                decks[c]= temp;
            }
        }
        public Card getcard()
        {
            Card c = decks[decks.Count - 1];
            decks.RemoveAt(decks.Count-1);
            return c;
           
        }
        public void scoring(ref int score)
        {
            
            score++;
            
        }
        public void print(ref int score)
        {
            Console.WriteLine("your score is:" + (score-1));
        }
    }
}
