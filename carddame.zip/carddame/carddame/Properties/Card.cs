﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace carddame.Properties
{
    class Card
    {
        public int suit;
        public int number;
        public Card(int suit,int number)
        {
            this.suit = suit;
            this.number = number;
        }
    }
}
